const socket = io();
let me = null;
let worldData = null;

const $ = id => document.getElementById(id);

$("enter").onclick = () => {
  const name = $("name").value.trim() || "Player";
  socket.emit("join", {name, city: $("city").value});
  $("start").hidden = true;
  $("game").hidden = false;
};

socket.on("world", data => {
  worldData = data.cities;
  me = data.me;
  render();
});

socket.on("me", p => { me = p; renderHeader(); });
socket.on("players", list => renderPlayers(list));
socket.on("chat", item => {
  const div = document.createElement("div");
  div.className = "msg";
  div.innerHTML = `<b>${escapeHtml(item.name)}</b> <span>${escapeHtml(item.message)}</span>`;
  $("chat").appendChild(div);
  $("chat").scrollTop = $("chat").scrollHeight;
});
socket.on("activityResult", r => {
  $("xp").textContent = r.xp;
  alert(r.message);
});

function render(){
  renderHeader();
  renderPlaces();
  renderPlayers([]);
  $("travel").value = me.city;
}

function renderHeader(){
  if(!me) return;
  const c = worldData?.[me.city];
  $("location").textContent = `${c?.name || me.city} · ${c?.country || ""}`;
  $("coins").textContent = me.coins;
  $("xp").textContent = me.xp;
  $("travel").value = me.city;
  $("me").style.left = me.x + "%";
  $("me").style.top = me.y + "%";
}

function renderPlaces(){
  const box = $("places");
  box.innerHTML = "";
  const city = worldData[me.city];
  city.places.forEach(p => {
    const el = document.createElement("button");
    el.className = "place";
    el.style.left = p.x + "%";
    el.style.top = p.y + "%";
    el.innerHTML = `${escapeHtml(p.name)}<span>${escapeHtml(p.type)}</span>`;
    el.onclick = e => {
      e.stopPropagation();
      socket.emit("activity", {placeId:p.id});
    };
    box.appendChild(el);
  });
}

function renderPlayers(list){
  document.querySelectorAll(".other,.otherlabel").forEach(e => e.remove());
  list.filter(p => !me || p.id !== me.id).forEach(p => {
    const a = document.createElement("div");
    a.className = "avatar other";
    a.style.left = p.x + "%";
    a.style.top = p.y + "%";
    a.textContent = "P";
    $("players").appendChild(a);

    const l = document.createElement("div");
    l.className = "otherlabel";
    l.style.left = p.x + "%";
    l.style.top = p.y + "%";
    l.textContent = p.name;
    $("players").appendChild(l);
  });
}

$("world").onclick = e => {
  const r = $("world").getBoundingClientRect();
  const x = ((e.clientX-r.left)/r.width)*100;
  const y = ((e.clientY-r.top)/r.height)*100;
  socket.emit("move",{x,y});
  if(me){me.x=x;me.y=y;renderHeader();}
};

$("travel").onchange = e => socket.emit("travel", e.target.value);

$("chatForm").onsubmit = e => {
  e.preventDefault();
  const input = $("chatInput");
  if(input.value.trim()) socket.emit("chat", input.value.trim());
  input.value = "";
};

$("invite").onclick = () => {
  const code = Math.random().toString(36).slice(2,8).toUpperCase();
  const url = `${location.origin}/?invite=${code}`;
  $("inviteBox").innerHTML = `<div class="invite"><b>Date Invite</b><br>${url}<br><br>Invite code: <b>${code}</b></div>`;
};

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}