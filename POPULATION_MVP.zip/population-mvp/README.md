# POPULATION MVP

A runnable Phase-1 web prototype for the POPULATION concept.

## Included
- Lagos, London, New York and Toronto city hubs
- Click/tap movement
- Multiplayer presence with Socket.IO
- City travel
- Interactive hotels, nightlife, arcades and landmarks
- Live city chat
- XP system
- Date Invite generator
- USD-denominated internal economy concept

## Run
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

This is a prototype, not the production game. A production version should add accounts, PostgreSQL, moderation/reporting, persistent inventories, payments, real map/POI data, proper invite persistence, age/safety controls, and production hosting.
