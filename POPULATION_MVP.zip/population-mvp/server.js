const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));

const cities = {
  lagos: {
    country: "Nigeria",
    name: "Lagos",
    places: [
      { id:"lekki-nightlife", name:"Lekki Nightlife", type:"Nightclub", x:72, y:34, activity:"Dance, meet people & join events" },
      { id:"vi-hotel", name:"Victoria Island Hotel", type:"Hotel", x:30, y:24, activity:"Book a room or start a date" },
      { id:"ikeja-arcade", name:"Ikeja Arcade", type:"Arcade", x:46, y:68, activity:"Play games & earn XP" },
      { id:"lagos-beach", name:"Lagos Beach", type:"Beach", x:77, y:76, activity:"Relax, chat & meet players" }
    ]
  },
  london: {
    country: "United Kingdom",
    name: "London",
    places: [
      { id:"soho-club", name:"Soho Nightlife", type:"Nightclub", x:67, y:30, activity:"Dance, meet people & join events" },
      { id:"westminster-hotel", name:"Westminster Hotel", type:"Hotel", x:34, y:26, activity:"Book a room or start a date" },
      { id:"camden-arcade", name:"Camden Arcade", type:"Arcade", x:46, y:66, activity:"Play games & earn XP" },
      { id:"southbank", name:"South Bank", type:"Landmark", x:78, y:73, activity:"Explore & socialize" }
    ]
  },
  newyork: {
    country: "United States",
    name: "New York",
    places: [
      { id:"manhattan-club", name:"Manhattan Nightlife", type:"Nightclub", x:70, y:29, activity:"Dance, meet people & join events" },
      { id:"midtown-hotel", name:"Midtown Hotel", type:"Hotel", x:34, y:24, activity:"Book a room or start a date" },
      { id:"brooklyn-arcade", name:"Brooklyn Arcade", type:"Arcade", x:44, y:67, activity:"Play games & earn XP" },
      { id:"central-park", name:"Central Park", type:"Park", x:77, y:75, activity:"Relax & socialize" }
    ]
  },
  toronto: {
    country: "Canada",
    name: "Toronto",
    places: [
      { id:"downtown-club", name:"Downtown Nightlife", type:"Nightclub", x:70, y:30, activity:"Dance, meet people & join events" },
      { id:"north-york-hotel", name:"North York Hotel", type:"Hotel", x:33, y:24, activity:"Book a room or start a date" },
      { id:"scarborough-arcade", name:"Scarborough Arcade", type:"Arcade", x:44, y:67, activity:"Play games & earn XP" },
      { id:"lakefront", name:"Lakefront", type:"Landmark", x:77, y:75, activity:"Relax & socialize" }
    ]
  }
};

const players = new Map();

io.on("connection", socket => {
  socket.on("join", ({ name, city }) => {
    const safeName = String(name || "Player").slice(0, 20);
    const safeCity = cities[city] ? city : "lagos";
    players.set(socket.id, {
      id: socket.id,
      name: safeName,
      city: safeCity,
      x: 50,
      y: 50,
      coins: 100,
      xp: 0
    });
    socket.join(safeCity);
    socket.emit("world", { cities, me: players.get(socket.id) });
    broadcastCity(safeCity);
  });

  socket.on("move", ({ x, y }) => {
    const p = players.get(socket.id);
    if (!p) return;
    p.x = Math.max(3, Math.min(97, Number(x) || 50));
    p.y = Math.max(5, Math.min(95, Number(y) || 50));
    broadcastCity(p.city);
  });

  socket.on("travel", city => {
    const p = players.get(socket.id);
    if (!p || !cities[city] || p.city === city) return;
    socket.leave(p.city);
    p.city = city;
    p.x = 50; p.y = 50;
    socket.join(city);
    socket.emit("me", p);
    socket.emit("world", { cities, me: p });
    broadcastAll();
  });

  socket.on("chat", message => {
    const p = players.get(socket.id);
    if (!p) return;
    const clean = String(message || "").trim().slice(0, 160);
    if (!clean) return;
    io.to(p.city).emit("chat", { name: p.name, message: clean });
  });

  socket.on("activity", ({ placeId }) => {
    const p = players.get(socket.id);
    if (!p) return;
    const place = cities[p.city].places.find(x => x.id === placeId);
    if (!place) return;
    p.xp += 10;
    io.to(socket.id).emit("activityResult", {
      place: place.name,
      xp: p.xp,
      message: `You entered ${place.name}. +10 XP`
    });
    broadcastCity(p.city);
  });

  socket.on("disconnect", () => {
    const p = players.get(socket.id);
    if (p) {
      players.delete(socket.id);
      broadcastCity(p.city);
    }
  });
});

function broadcastCity(city) {
  io.to(city).emit("players", [...players.values()].filter(p => p.city === city));
}
function broadcastAll() {
  for (const city of Object.keys(cities)) broadcastCity(city);
}

server.listen(PORT, () => console.log(`POPULATION running at http://localhost:${PORT}`));